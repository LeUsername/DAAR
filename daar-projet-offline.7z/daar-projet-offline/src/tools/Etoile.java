package tools;

/**
 * Les états numérotés entre x et y (inclus) sont affectes par l'operateur * de la regex.
 * @author 341045
 *
 */
public class Etoile {
	public int x;
	public int y;

	public Etoile(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
